package fr.chronopost.labs.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebServlet(asyncSupported = false, value = "/alpha.json", loadOnStartup = 1)
public class AlphaJsonServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7457972278668830558L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("application/json");

		PrintWriter out = response.getWriter();

		ObjectMapper mapper = new ObjectMapper();

		mapper.writeValue(out, getBeans());

		out.flush();

	}

	protected void doGet(HttpServletRequest req, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(req, response);

	}

	private Object getBeans() {

		Calendar c = GregorianCalendar.getInstance();

		int seconds = c.get(Calendar.SECOND);

		return getAllSpeakers(seconds);

	}

	private List<UserBean> getAllSpeakers(int nb) {

		if (nb == 0) {
			nb = 1;
		}
		Random random = new Random();

		java.util.List<UserBean> l = new LinkedList<UserBean>();

		Cluster cluster;
		Session session;

		cluster = Cluster.builder().addContactPoint("192.168.56.101").build();
		session = cluster.connect("devoxx");

		ResultSet results = session.execute("select * from speakers limit "
				+ nb + ";");

		for (Row row : results) {

			UserBean u = new UserBean();
			u.setChamp1(row.getString("speaker"));
			u.setDate3(new Date());
			u.setMax(random.nextInt(5000));

			l.add(u);

		}

		return l;
	}

}
